import os

from dotenv import load_dotenv

load_dotenv()

GOOGLE_ADK_API_KEY = os.getenv("GOOGLE_ADK_API_KEY", "")
FLUX_MCP_ENDPOINT = os.getenv("FLUX_MCP_ENDPOINT", "http://localhost:8080/flux")
OUTPUT_BASE_DIR = os.getenv("OUTPUT_BASE_DIR", "./output")
WEAKNESS_THRESHOLD = float(os.getenv("WEAKNESS_THRESHOLD", "0.7"))
PROMPTS_PER_CATEGORY = int(os.getenv("PROMPTS_PER_CATEGORY", "10"))
QUALITY_MIN_ALIGNMENT = float(os.getenv("QUALITY_MIN_ALIGNMENT", "0.75"))
