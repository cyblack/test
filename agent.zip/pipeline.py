import asyncio
import json
import sys

from google.adk.agents import SequentialAgent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

from agents import (
    BenchmarkAnalysisAgent,
    FileSystemCheckAgent,
    ImageGenerationAgent,
    ImageQualityCheckAgent,
    PromptGenerationAgent,
    PromptValidationAgent,
    ReportAgent,
    WeaknessSpecAgent,
)

pipeline = SequentialAgent(
    name="BenchmarkDataAugmentationPipeline",
    description="Benchmark 분석 기반 데이터 생성 파이프라인",
    sub_agents=[
        BenchmarkAnalysisAgent,     # Agent 1: 벤치마크 분석
        WeaknessSpecAgent,          # Agent 2: 약점 스펙 생성
        PromptGenerationAgent,      # Agent 3: 프롬프트 생성
        PromptValidationAgent,      # Agent 4: 프롬프트 검증
        ImageGenerationAgent,       # Agent 5: 이미지 생성 (MCP)
        ImageQualityCheckAgent,     # Agent 6: 이미지 품질 검수
        FileSystemCheckAgent,       # Agent 7: 파일 시스템 검증
        ReportAgent,                # Agent 8: 최종 보고서
    ],
)


async def run_pipeline(benchmark_json_path: str) -> None:
    """벤치마크 JSON 파일 경로를 받아 파이프라인을 실행합니다."""
    with open(benchmark_json_path, "r", encoding="utf-8") as f:
        benchmark_data = json.load(f)

    session_service = InMemorySessionService()
    session = await session_service.create_session(
        app_name="benchmark_augmentation",
        user_id="pipeline_user",
    )

    runner = Runner(
        agent=pipeline,
        app_name="benchmark_augmentation",
        session_service=session_service,
    )

    user_message = types.Content(
        role="user",
        parts=[types.Part.from_text(
            text=f"다음 benchmark JSON 데이터를 분석하고 부족한 데이터를 생성해주세요:\n\n{json.dumps(benchmark_data, ensure_ascii=False, indent=2)}"
        )],
    )

    print("파이프라인 실행을 시작합니다...")
    print(f"입력 파일: {benchmark_json_path}")
    print("-" * 60)

    async for event in runner.run_async(
        session_id=session.id,
        user_id="pipeline_user",
        new_message=user_message,
    ):
        if event.content and event.content.parts:
            agent_name = event.author or "unknown"
            for part in event.content.parts:
                if part.text:
                    print(f"[{agent_name}] {part.text[:200]}...")

    print("-" * 60)
    print("파이프라인 실행이 완료되었습니다.")


def main():
    if len(sys.argv) < 2:
        print("사용법: python pipeline.py <benchmark_json_path>")
        sys.exit(1)

    benchmark_json_path = sys.argv[1]
    asyncio.run(run_pipeline(benchmark_json_path))


if __name__ == "__main__":
    main()
