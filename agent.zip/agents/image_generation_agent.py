import os

from google.adk.agents import LlmAgent
from google.adk.tools import MCPTool

from config.settings import FLUX_MCP_ENDPOINT, OUTPUT_BASE_DIR
from schemas import ImageGenerationResult

flux_generate_tool = MCPTool(
    name="flux_generate",
    description="Flux 2 Dev MCP 서버를 통해 이미지를 생성합니다",
    server_url=FLUX_MCP_ENDPOINT,
)

ImageGenerationAgent = LlmAgent(
    name="ImageGenerationAgent",
    model="gemini-2.0-flash",
    description="MCP를 통해 Flux 2 Dev API를 호출하여 이미지를 생성하는 Agent",
    instruction=f"""당신은 이미지 생성 파이프라인을 관리하는 Agent입니다.

이전 Agent(PromptValidationAgent)가 승인한 프롬프트 목록을 받아 다음을 수행하세요:

1. approved_prompts의 각 프롬프트에 대해 flux_generate 도구를 호출하여 이미지를 생성합니다.
2. 생성된 이미지는 카테고리별 디렉토리에 저장합니다:
   - 경로 형식: {OUTPUT_BASE_DIR}/images/{{target_category}}/{{prompt_id}}_seed{{seed}}.png
3. 각 생성 결과의 메타데이터(steps, cfg, seed 등)를 기록합니다.
4. 실패한 프롬프트의 ID를 failed_prompt_ids에 기록합니다.
5. output_directory에 이미지 저장 루트 경로를 기록합니다.

주의사항:
- 네트워크 오류 시 최대 2회 재시도합니다.
- seed 값이 지정된 경우 반드시 해당 seed를 사용합니다.
- 파일명에 특수문자가 포함되지 않도록 합니다.

출력은 반드시 ImageGenerationResult 스키마를 따라야 합니다.
""",
    tools=[flux_generate_tool],
    output_schema=ImageGenerationResult,
)
