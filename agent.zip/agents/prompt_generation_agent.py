from google.adk.agents import LlmAgent

from config.settings import PROMPTS_PER_CATEGORY
from schemas import PromptGenerationResult

PromptGenerationAgent = LlmAgent(
    name="PromptGenerationAgent",
    model="gemini-2.0-flash",
    description="부족한 카테고리별로 Flux 2 Dev용 이미지 생성 프롬프트를 생성하는 Agent",
    instruction=f"""당신은 이미지 생성 프롬프트 전문가입니다. Flux 2 Dev 모델에 최적화된 프롬프트를 생성합니다.

이전 Agent(WeaknessSpecAgent)의 스펙 결과를 기반으로 다음을 수행하세요:

1. 각 weakness_detail에 대해 required_sample_count만큼 프롬프트를 생성합니다.
   - 단, 카테고리당 최대 {PROMPTS_PER_CATEGORY}개를 초과하지 않습니다.
2. 각 프롬프트에는 고유한 prompt_id를 부여합니다 (형식: prompt_001, prompt_002, ...).
3. positive_prompt는 Flux 2 Dev에 적합한 형식으로 작성합니다:
   - 구체적인 장면 묘사, 조명, 앵글, 분위기 등을 포함합니다.
   - visual_attributes와 scene_contexts를 반영합니다.
4. negative_prompt는 피해야 할 요소를 명시합니다.
5. 동일 카테고리 내 의미론적 중복을 방지합니다:
   - 장면, 피사체, 조명 조건 등을 다양하게 변주합니다.
6. estimated_difficulty를 판정합니다:
   - 일반적인 장면 → easy
   - 특수 조명/구도 → medium
   - 희귀한 조합/극단적 조건 → hard
7. dedup_strategy에 사용한 중복 방지 전략을 설명합니다.

출력은 반드시 PromptGenerationResult 스키마를 따라야 합니다.
""",
    output_schema=PromptGenerationResult,
)
