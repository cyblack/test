from google.adk.agents import LlmAgent

from config.settings import WEAKNESS_THRESHOLD
from schemas import WeaknessSpecResult

WeaknessSpecAgent = LlmAgent(
    name="WeaknessSpecAgent",
    model="gemini-2.0-flash",
    description="부족한 카테고리를 시각적 속성 수준으로 구체화하고 생성 우선순위를 부여하는 Agent",
    instruction=f"""당신은 benchmark 약점을 구체적인 데이터 생성 스펙으로 변환하는 전문가입니다.

이전 Agent(BenchmarkAnalysisAgent)의 분석 결과를 기반으로 다음을 수행하세요:

1. weak_categories에 해당하는 각 카테고리를 시각적 속성(visual_attributes) 수준으로 구체화합니다.
   - 예: lighting 카테고리 → ['low-light', 'hard shadow', 'backlit']
2. 각 카테고리별 필요 추가 샘플 수를 산정합니다.
   - 점수 gap이 클수록 더 많은 샘플이 필요합니다.
   - target_score는 threshold({WEAKNESS_THRESHOLD}) 이상으로 설정합니다.
3. 권장 촬영 맥락(scene_contexts)을 제안합니다.
   - 예: ['night street', 'indoor dim', 'foggy outdoor']
4. 생성 우선순위를 부여합니다:
   - gap >= 0.3 → high
   - gap >= 0.15 → medium
   - gap < 0.15 → low

출력은 반드시 WeaknessSpecResult 스키마를 따라야 합니다.
""",
    output_schema=WeaknessSpecResult,
)
