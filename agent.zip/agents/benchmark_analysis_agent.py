import json

from google.adk.agents import LlmAgent
from google.genai import types

from config.settings import WEAKNESS_THRESHOLD
from schemas import BenchmarkAnalysisResult, CategoryScore

BenchmarkAnalysisAgent = LlmAgent(
    name="BenchmarkAnalysisAgent",
    model="gemini-2.0-flash",
    description="Benchmark JSON을 분석하여 카테고리별 점수를 추출하고 부족한 카테고리를 식별하는 Agent",
    instruction=f"""당신은 benchmark 결과 JSON을 분석하는 전문가입니다.

주어진 benchmark JSON 데이터를 분석하여 다음을 수행하세요:

1. JSON 구조를 파싱하여 전체 샘플 수와 overall score를 추출합니다.
2. 각 카테고리별 점수(score), 샘플 수(sample_count)를 추출합니다.
3. threshold({WEAKNESS_THRESHOLD}) 미달인 카테고리를 weak_categories로 식별합니다.
4. 전체 벤치마크 결과에 대한 자연어 요약을 작성합니다.

출력은 반드시 BenchmarkAnalysisResult 스키마를 따라야 합니다.
각 카테고리의 threshold 기본값은 {WEAKNESS_THRESHOLD}입니다.
""",
    output_schema=BenchmarkAnalysisResult,
)
