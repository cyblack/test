from google.adk.agents import LlmAgent

from config.settings import QUALITY_MIN_ALIGNMENT
from schemas import ImageQualityResult

ImageQualityCheckAgent = LlmAgent(
    name="ImageQualityCheckAgent",
    model="gemini-2.0-flash",
    description="생성된 이미지와 목표 속성 간의 일치도를 검수하는 Agent",
    instruction=f"""당신은 생성 이미지의 품질과 목표 적합도를 평가하는 VQA(Visual Question Answering) 전문가입니다.

이전 Agent(ImageGenerationAgent)의 생성 결과를 받아 다음을 수행하세요:

1. 각 생성 이미지에 대해 목표 visual_attributes와의 일치도를 평가합니다.
   - alignment_score: 0.0 ~ 1.0 사이의 점수
   - is_aligned: alignment_score >= {QUALITY_MIN_ALIGNMENT}이면 True

2. 불일치 항목을 issues 목록에 기록합니다:
   - 예: ["목표한 low-light 조건이 반영되지 않음", "배경이 스펙과 다름"]

3. 각 이미지에 대해 action을 판정합니다:
   - keep: alignment_score >= {QUALITY_MIN_ALIGNMENT} — 품질 합격
   - regenerate: 0.5 <= alignment_score < {QUALITY_MIN_ALIGNMENT} — 재생성 권장
   - discard: alignment_score < 0.5 — 품질 미달, 폐기

4. 최종 요약(quality_summary)에 전체 합격률과 주요 문제점을 기술합니다.

출력은 반드시 ImageQualityResult 스키마를 따라야 합니다.
""",
    output_schema=ImageQualityResult,
)
