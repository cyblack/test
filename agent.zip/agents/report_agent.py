import os
from datetime import datetime, timezone

from google.adk.agents import LlmAgent
from google.adk.tools import FunctionTool

from config.settings import OUTPUT_BASE_DIR
from schemas import FinalReport


def save_markdown_report(report_content: str) -> str:
    """마크다운 보고서를 파일로 저장하고 경로를 반환합니다."""
    reports_dir = os.path.join(OUTPUT_BASE_DIR, "reports")
    os.makedirs(reports_dir, exist_ok=True)

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    file_path = os.path.join(reports_dir, f"report_{timestamp}.md")

    with open(file_path, "w", encoding="utf-8") as f:
        f.write(report_content)

    return os.path.abspath(file_path)


def save_pipeline_metadata(metadata_json: str) -> str:
    """파이프라인 메타데이터를 JSON 파일로 저장하고 경로를 반환합니다."""
    metadata_dir = os.path.join(OUTPUT_BASE_DIR, "metadata")
    os.makedirs(metadata_dir, exist_ok=True)

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    file_path = os.path.join(metadata_dir, f"pipeline_result_{timestamp}.json")

    with open(file_path, "w", encoding="utf-8") as f:
        f.write(metadata_json)

    return os.path.abspath(file_path)


save_report_tool = FunctionTool(func=save_markdown_report)
save_metadata_tool = FunctionTool(func=save_pipeline_metadata)

ReportAgent = LlmAgent(
    name="ReportAgent",
    model="gemini-2.0-flash",
    description="전체 파이프라인 결과를 집계하여 최종 보고서를 생성하는 Agent",
    instruction=f"""당신은 데이터 증강 파이프라인의 최종 보고서를 작성하는 Agent입니다.

이전 모든 Agent의 결과를 종합하여 다음을 수행하세요:

1. **카테고리별 before/after 비교**:
   - BenchmarkAnalysisResult의 category_scores에서 before_score를 가져옵니다.
   - 생성된 이미지 수와 품질 검수 결과를 기반으로 after_estimated_score를 추정합니다.
   - 각 카테고리에서 대표 프롬프트 최대 3개를 선별합니다.

2. **전체 통계 집계**:
   - total_images_generated: 생성 시도된 총 이미지 수
   - total_images_approved: 품질 검수를 통과한 이미지 수
   - failed_items: 실패한 항목 목록 (생성 실패 + 품질 미달 + 파일 손상)

3. **Markdown 보고서 작성 및 저장**:
   - save_markdown_report 도구를 사용하여 보고서를 저장합니다.
   - 보고서에는 요약, 카테고리별 상세, 실패 항목, 권장 사항을 포함합니다.

4. **파이프라인 메타데이터 저장**:
   - save_pipeline_metadata 도구를 사용하여 전체 결과를 JSON으로 저장합니다.

5. **executive_summary 작성**:
   - 경영진이 읽을 수 있는 1~2문단의 핵심 요약을 작성합니다.

output_directory: {OUTPUT_BASE_DIR}

출력은 반드시 FinalReport 스키마를 따라야 합니다.
""",
    tools=[save_report_tool, save_metadata_tool],
    output_schema=FinalReport,
)
