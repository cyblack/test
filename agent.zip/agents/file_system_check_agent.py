from google.adk.agents import LlmAgent
from google.adk.tools import FunctionTool

from schemas import FileSystemCheckResult


def check_file(file_path: str) -> dict:
    """파일 존재 여부, 크기, 손상 여부를 확인합니다."""
    import os

    result = {
        "file_path": file_path,
        "exists": False,
        "file_size_bytes": 0,
        "is_corrupted": False,
    }

    if not os.path.exists(file_path):
        return result

    result["exists"] = True
    result["file_size_bytes"] = os.path.getsize(file_path)

    # 파일 크기가 0이면 손상으로 간주
    if result["file_size_bytes"] == 0:
        result["is_corrupted"] = True
        return result

    # PNG 헤더 검증
    if file_path.lower().endswith(".png"):
        try:
            with open(file_path, "rb") as f:
                header = f.read(8)
            png_signature = b"\x89PNG\r\n\x1a\n"
            if header != png_signature:
                result["is_corrupted"] = True
        except OSError:
            result["is_corrupted"] = True

    return result


def list_directory_structure(base_dir: str) -> dict:
    """카테고리별 디렉토리 구조와 파일 수를 반환합니다."""
    import os

    structure = {}
    images_dir = os.path.join(base_dir, "images")

    if not os.path.exists(images_dir):
        return structure

    for category in os.listdir(images_dir):
        category_path = os.path.join(images_dir, category)
        if os.path.isdir(category_path):
            files = [f for f in os.listdir(category_path) if f.endswith(".png")]
            structure[category] = len(files)

    return structure


check_file_tool = FunctionTool(func=check_file)
list_directory_tool = FunctionTool(func=list_directory_structure)

FileSystemCheckAgent = LlmAgent(
    name="FileSystemCheckAgent",
    model="gemini-2.0-flash",
    description="생성된 이미지 파일의 존재 여부와 무결성을 검증하는 Agent",
    instruction="""당신은 파일 시스템 무결성을 검증하는 Agent입니다.

이전 Agent들(ImageGenerationAgent, ImageQualityCheckAgent)의 결과를 받아 다음을 수행하세요:

1. ImageQualityCheckAgent에서 keep 판정된 이미지의 파일을 check_file 도구로 검증합니다:
   - 파일 존재 여부
   - 파일 크기 (0바이트 = 손상)
   - PNG 헤더 무결성

2. 카테고리별 디렉토리 구조를 list_directory_structure 도구로 확인합니다.

3. 각 파일이 올바른 카테고리 디렉토리에 저장되었는지 확인합니다:
   - target_category와 실제 저장 경로의 디렉토리명이 일치해야 합니다.

4. 누락 파일(missing_files)과 손상 파일(corrupted_files) 목록을 생성합니다.

5. all_passed는 모든 검사를 통과한 경우에만 True입니다.

출력은 반드시 FileSystemCheckResult 스키마를 따라야 합니다.
""",
    tools=[check_file_tool, list_directory_tool],
    output_schema=FileSystemCheckResult,
)
