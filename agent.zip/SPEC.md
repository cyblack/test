# SPEC.md — Benchmark 분석 기반 데이터 생성 Agent

## 개요

Google ADK(Agent Development Kit)를 활용하여 benchmark 결과 JSON을 분석하고,
부족한 데이터를 자동으로 생성하는 Sequential Agent 파이프라인.

이미지 생성 모델로 **Flux 2 Dev**를 사용하며, 각 Agent 간 데이터는 **Pydantic Schema**로 타입을 보장한다.

---

## 시스템 아키텍처

```
BenchmarkJSON
     │
     ▼
[Agent 1] BenchmarkAnalysisAgent       ─→ BenchmarkAnalysisResult
     │
     ▼
[Agent 2] WeaknessSpecAgent            ─→ WeaknessSpecResult
     │
     ▼
[Agent 3] PromptGenerationAgent        ─→ PromptGenerationResult
     │
     ▼
[Agent 4] PromptValidationAgent        ─→ ValidatedPromptResult          ← 추가
     │
     ▼
[Agent 5] ImageGenerationAgent (MCP)   ─→ ImageGenerationResult
     │
     ▼
[Agent 6] ImageQualityCheckAgent       ─→ ImageQualityResult             ← 5단계 분리
     │
     ▼
[Agent 7] FileSystemCheckAgent         ─→ FileSystemCheckResult          ← 5단계 분리
     │
     ▼
[Agent 8] ReportAgent                  ─→ FinalReport
```

---

## Schema 정의

모든 Agent 간 입출력은 아래 Pydantic Schema를 따른다.

### 공통

```python
from pydantic import BaseModel, Field
from typing import Literal

class CategoryScore(BaseModel):
    category: str = Field(description="평가 카테고리명 (예: lighting, occlusion, background)")
    score: float = Field(ge=0.0, le=1.0, description="0~1 사이 점수")
    sample_count: int = Field(ge=0, description="해당 카테고리의 샘플 수")
    threshold: float = Field(default=0.7, description="합격 기준 점수")
```

---

### Agent 1 — BenchmarkAnalysisAgent

**입력:** Raw benchmark JSON 파일 경로 (str)

**출력:** `BenchmarkAnalysisResult`

```python
class BenchmarkAnalysisResult(BaseModel):
    total_sample_count: int
    overall_score: float = Field(ge=0.0, le=1.0)
    category_scores: list[CategoryScore]
    weak_categories: list[str] = Field(
        description="threshold 미달 카테고리 목록"
    )
    analysis_summary: str = Field(
        description="전체 벤치마크 결과에 대한 자연어 요약"
    )
```

**역할:**
- JSON 구조 파싱 및 카테고리별 점수 추출
- threshold 미달 카테고리 식별
- 전체 품질 수준 요약

---

### Agent 2 — WeaknessSpecAgent

**입력:** `BenchmarkAnalysisResult`

**출력:** `WeaknessSpecResult`

```python
class WeaknessDetail(BaseModel):
    category: str
    current_score: float
    target_score: float
    gap: float = Field(description="target - current")
    required_sample_count: int = Field(
        description="점수 향상을 위해 필요한 추가 샘플 수 (추정)"
    )
    visual_attributes: list[str] = Field(
        description="해당 카테고리의 부족한 시각적 속성 (예: ['low-light', 'hard shadow'])"
    )
    scene_contexts: list[str] = Field(
        description="권장 촬영 맥락 (예: ['night street', 'indoor dim'])"
    )
    priority: Literal["high", "medium", "low"]

class WeaknessSpecResult(BaseModel):
    weakness_details: list[WeaknessDetail]
    total_required_images: int
    spec_summary: str
```

**역할:**
- 부족한 카테고리를 시각적 속성 수준으로 구체화
- 카테고리별 필요 추가 샘플 수 산정
- 생성 우선순위(high/medium/low) 부여

---

### Agent 3 — PromptGenerationAgent

**입력:** `WeaknessSpecResult`

**출력:** `PromptGenerationResult`

```python
class ImagePrompt(BaseModel):
    prompt_id: str = Field(description="고유 ID, 예: prompt_001")
    target_category: str
    target_attributes: list[str]
    positive_prompt: str = Field(description="Flux용 positive prompt")
    negative_prompt: str = Field(description="Flux용 negative prompt")
    seed: int | None = Field(default=None, description="재현성을 위한 seed 값")
    estimated_difficulty: Literal["easy", "medium", "hard"]

class PromptGenerationResult(BaseModel):
    prompts: list[ImagePrompt]
    total_prompt_count: int
    dedup_strategy: str = Field(
        description="중복 방지를 위해 사용한 전략 설명"
    )
```

**역할:**
- 각 weakness에 대해 N개의 프롬프트 생성 (N은 `required_sample_count`)
- 동일 카테고리 내 의미론적 중복 방지
- Flux 2 Dev 프롬프트 형식 준수

---

### Agent 4 — PromptValidationAgent *(추가)*

**입력:** `PromptGenerationResult`

**출력:** `ValidatedPromptResult`

```python
class PromptValidationStatus(BaseModel):
    prompt_id: str
    is_valid: bool
    rejection_reason: str | None = None
    revised_prompt: ImagePrompt | None = Field(
        description="수정이 필요한 경우 revised 버전"
    )

class ValidatedPromptResult(BaseModel):
    validation_results: list[PromptValidationStatus]
    approved_prompts: list[ImagePrompt]
    rejected_count: int
    approved_count: int
    validation_summary: str
```

**역할:**
- 프롬프트 간 의미 중복 최종 검수
- 너무 추상적이거나 생성 불가능한 프롬프트 필터링
- 반려된 프롬프트는 자동 수정 후 재포함

---

### Agent 5 — ImageGenerationAgent (MCP)

**입력:** `ValidatedPromptResult`

**출력:** `ImageGenerationResult`

```python
class GeneratedImage(BaseModel):
    prompt_id: str
    file_path: str = Field(description="저장된 이미지 절대 경로")
    file_name: str
    target_category: str
    used_prompt: ImagePrompt
    generation_metadata: dict = Field(
        description="Flux 반환 메타데이터 (steps, cfg, seed 등)"
    )

class ImageGenerationResult(BaseModel):
    generated_images: list[GeneratedImage]
    total_generated: int
    failed_prompt_ids: list[str]
    output_directory: str
```

**역할:**
- MCP를 통해 Flux 2 Dev API 호출
- 생성된 이미지를 카테고리별 디렉토리에 저장
- 실패한 프롬프트 기록

---

### Agent 6 — ImageQualityCheckAgent *(분리)*

**입력:** `ImageGenerationResult`

**출력:** `ImageQualityResult`

```python
class ImageQualityStatus(BaseModel):
    file_path: str
    prompt_id: str
    target_category: str
    is_aligned: bool = Field(
        description="생성 이미지가 목표 visual_attributes와 일치하는지 여부"
    )
    alignment_score: float = Field(ge=0.0, le=1.0)
    issues: list[str] = Field(description="불일치 항목 목록")
    action: Literal["keep", "regenerate", "discard"]

class ImageQualityResult(BaseModel):
    quality_statuses: list[ImageQualityStatus]
    passed_count: int
    regenerate_count: int
    discard_count: int
    quality_summary: str
```

**역할:**
- 생성된 이미지와 target_attributes 일치 여부 검수 (VQA)
- keep / regenerate / discard 판정
- 재생성 대상은 Agent 5로 피드백 (루프 옵션)

---

### Agent 7 — FileSystemCheckAgent *(분리)*

**입력:** `ImageGenerationResult` + `ImageQualityResult`

**출력:** `FileSystemCheckResult`

```python
class FileCheckStatus(BaseModel):
    file_path: str
    exists: bool
    file_size_bytes: int
    is_corrupted: bool
    category_directory_correct: bool

class FileSystemCheckResult(BaseModel):
    file_checks: list[FileCheckStatus]
    all_passed: bool
    missing_files: list[str]
    corrupted_files: list[str]
    directory_structure: dict = Field(
        description="카테고리별 생성 파일 수 요약"
    )
```

**역할:**
- 파일 존재 여부 및 무결성 확인
- 카테고리별 디렉토리 구조 검증
- 누락·손상 파일 목록화

---

### Agent 8 — ReportAgent

**입력:** 이전 모든 Agent 결과

**출력:** `FinalReport`

```python
class CategoryAugmentationSummary(BaseModel):
    category: str
    before_score: float
    after_estimated_score: float
    images_added: int
    sample_prompts: list[str] = Field(description="대표 프롬프트 3개 이내")

class FinalReport(BaseModel):
    report_title: str
    created_at: str = Field(description="ISO 8601 형식")
    overall_before_score: float
    overall_after_estimated_score: float
    category_summaries: list[CategoryAugmentationSummary]
    total_images_generated: int
    total_images_approved: int
    failed_items: list[str]
    output_directory: str
    markdown_report_path: str = Field(description="저장된 .md 보고서 경로")
    executive_summary: str
```

**역할:**
- 전체 파이프라인 결과 집계
- 카테고리별 before/after 점수 비교
- Markdown 보고서 파일로 저장

---

## 디렉토리 구조

```
output/
├── images/
│   ├── {category_1}/
│   │   ├── prompt_001_seed1234.png
│   │   └── prompt_002_seed5678.png
│   └── {category_2}/
│       └── prompt_003_seed9999.png
├── reports/
│   └── report_{timestamp}.md
└── metadata/
    └── pipeline_result_{timestamp}.json
```

---

## Sequential Agent 파이프라인 구성

```python
from google.adk.agents import SequentialAgent

pipeline = SequentialAgent(
    name="BenchmarkDataAugmentationPipeline",
    sub_agents=[
        BenchmarkAnalysisAgent,    # Agent 1
        WeaknessSpecAgent,         # Agent 2
        PromptGenerationAgent,     # Agent 3
        PromptValidationAgent,     # Agent 4
        ImageGenerationAgent,      # Agent 5 (MCP)
        ImageQualityCheckAgent,    # Agent 6
        FileSystemCheckAgent,      # Agent 7
        ReportAgent,               # Agent 8
    ]
)
```

각 Agent는 이전 Agent의 Schema 출력을 `input_schema`로 선언하여 타입 안전성을 보장한다.

---

## 환경 변수

| 변수명 | 설명 |
|---|---|
| `GOOGLE_ADK_API_KEY` | Google ADK 인증 키 |
| `FLUX_MCP_ENDPOINT` | Flux 2 Dev MCP 서버 엔드포인트 |
| `OUTPUT_BASE_DIR` | 이미지 및 보고서 저장 루트 디렉토리 |
| `WEAKNESS_THRESHOLD` | 부족 카테고리 판단 기준 점수 (기본값: 0.7) |
| `PROMPTS_PER_CATEGORY` | 카테고리당 최대 생성 프롬프트 수 (기본값: 10) |
| `QUALITY_MIN_ALIGNMENT` | 이미지 품질 검수 최소 alignment score (기본값: 0.75) |

---

## 추가 고려사항

- **재생성 루프:** Agent 6에서 `regenerate` 판정된 이미지는 Agent 5를 재호출하거나, 별도 retry 큐로 처리하는 방식을 선택할 수 있다.
- **비용 절감:** Agent 4(프롬프트 검수)를 통해 불필요한 이미지 생성을 사전 차단한다.
- **확장성:** 이미지 외 다른 데이터 모달리티(텍스트, 오디오)로 Agent 5를 교체하는 것이 가능하도록 `ImageGenerationAgent`를 인터페이스로 추상화하는 것을 권장한다.
