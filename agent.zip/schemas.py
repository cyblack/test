from typing import Literal

from pydantic import BaseModel, Field


# ──────────────────────────────────────
# 공통
# ──────────────────────────────────────

class CategoryScore(BaseModel):
    category: str = Field(description="평가 카테고리명 (예: lighting, occlusion, background)")
    score: float = Field(ge=0.0, le=1.0, description="0~1 사이 점수")
    sample_count: int = Field(ge=0, description="해당 카테고리의 샘플 수")
    threshold: float = Field(default=0.7, description="합격 기준 점수")


# ──────────────────────────────────────
# Agent 1 — BenchmarkAnalysisAgent
# ──────────────────────────────────────

class BenchmarkAnalysisResult(BaseModel):
    total_sample_count: int
    overall_score: float = Field(ge=0.0, le=1.0)
    category_scores: list[CategoryScore]
    weak_categories: list[str] = Field(
        description="threshold 미달 카테고리 목록"
    )
    analysis_summary: str = Field(
        description="전체 벤치마크 결과에 대한 자연어 요약"
    )


# ──────────────────────────────────────
# Agent 2 — WeaknessSpecAgent
# ──────────────────────────────────────

class WeaknessDetail(BaseModel):
    category: str
    current_score: float
    target_score: float
    gap: float = Field(description="target - current")
    required_sample_count: int = Field(
        description="점수 향상을 위해 필요한 추가 샘플 수 (추정)"
    )
    visual_attributes: list[str] = Field(
        description="해당 카테고리의 부족한 시각적 속성 (예: ['low-light', 'hard shadow'])"
    )
    scene_contexts: list[str] = Field(
        description="권장 촬영 맥락 (예: ['night street', 'indoor dim'])"
    )
    priority: Literal["high", "medium", "low"]


class WeaknessSpecResult(BaseModel):
    weakness_details: list[WeaknessDetail]
    total_required_images: int
    spec_summary: str


# ──────────────────────────────────────
# Agent 3 — PromptGenerationAgent
# ──────────────────────────────────────

class ImagePrompt(BaseModel):
    prompt_id: str = Field(description="고유 ID, 예: prompt_001")
    target_category: str
    target_attributes: list[str]
    positive_prompt: str = Field(description="Flux용 positive prompt")
    negative_prompt: str = Field(description="Flux용 negative prompt")
    seed: int | None = Field(default=None, description="재현성을 위한 seed 값")
    estimated_difficulty: Literal["easy", "medium", "hard"]


class PromptGenerationResult(BaseModel):
    prompts: list[ImagePrompt]
    total_prompt_count: int
    dedup_strategy: str = Field(
        description="중복 방지를 위해 사용한 전략 설명"
    )


# ──────────────────────────────────────
# Agent 4 — PromptValidationAgent
# ──────────────────────────────────────

class PromptValidationStatus(BaseModel):
    prompt_id: str
    is_valid: bool
    rejection_reason: str | None = None
    revised_prompt: ImagePrompt | None = Field(
        default=None,
        description="수정이 필요한 경우 revised 버전",
    )


class ValidatedPromptResult(BaseModel):
    validation_results: list[PromptValidationStatus]
    approved_prompts: list[ImagePrompt]
    rejected_count: int
    approved_count: int
    validation_summary: str


# ──────────────────────────────────────
# Agent 5 — ImageGenerationAgent
# ──────────────────────────────────────

class GeneratedImage(BaseModel):
    prompt_id: str
    file_path: str = Field(description="저장된 이미지 절대 경로")
    file_name: str
    target_category: str
    used_prompt: ImagePrompt
    generation_metadata: dict = Field(
        description="Flux 반환 메타데이터 (steps, cfg, seed 등)"
    )


class ImageGenerationResult(BaseModel):
    generated_images: list[GeneratedImage]
    total_generated: int
    failed_prompt_ids: list[str]
    output_directory: str


# ──────────────────────────────────────
# Agent 6 — ImageQualityCheckAgent
# ──────────────────────────────────────

class ImageQualityStatus(BaseModel):
    file_path: str
    prompt_id: str
    target_category: str
    is_aligned: bool = Field(
        description="생성 이미지가 목표 visual_attributes와 일치하는지 여부"
    )
    alignment_score: float = Field(ge=0.0, le=1.0)
    issues: list[str] = Field(description="불일치 항목 목록")
    action: Literal["keep", "regenerate", "discard"]


class ImageQualityResult(BaseModel):
    quality_statuses: list[ImageQualityStatus]
    passed_count: int
    regenerate_count: int
    discard_count: int
    quality_summary: str


# ──────────────────────────────────────
# Agent 7 — FileSystemCheckAgent
# ──────────────────────────────────────

class FileCheckStatus(BaseModel):
    file_path: str
    exists: bool
    file_size_bytes: int
    is_corrupted: bool
    category_directory_correct: bool


class FileSystemCheckResult(BaseModel):
    file_checks: list[FileCheckStatus]
    all_passed: bool
    missing_files: list[str]
    corrupted_files: list[str]
    directory_structure: dict = Field(
        description="카테고리별 생성 파일 수 요약"
    )


# ──────────────────────────────────────
# Agent 8 — ReportAgent
# ──────────────────────────────────────

class CategoryAugmentationSummary(BaseModel):
    category: str
    before_score: float
    after_estimated_score: float
    images_added: int
    sample_prompts: list[str] = Field(description="대표 프롬프트 3개 이내")


class FinalReport(BaseModel):
    report_title: str
    created_at: str = Field(description="ISO 8601 형식")
    overall_before_score: float
    overall_after_estimated_score: float
    category_summaries: list[CategoryAugmentationSummary]
    total_images_generated: int
    total_images_approved: int
    failed_items: list[str]
    output_directory: str
    markdown_report_path: str = Field(description="저장된 .md 보고서 경로")
    executive_summary: str
